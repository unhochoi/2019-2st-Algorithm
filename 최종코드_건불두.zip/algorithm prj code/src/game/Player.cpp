#include "Player.h"

Player::Player() {
}

Player::Player(int x, int y) {
  this->x = x;
  this->y = y;
}

Player::~Player() {
}

void Player::update(int keyCode) {
  int dx = 0, dy = 0;
  
  Direction d = getDirectionFromKeyCode(keyCode);
  getPointFromDirection(d, dx, dy);

  x += dx;
  y += dy;
}

void Player::render(Graphics& graphics) {
  graphics.render(GraphicsType::GameObject, "&", this->x, this->y, 0, true, false);
}