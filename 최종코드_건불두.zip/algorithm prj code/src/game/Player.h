#include "./common/Header.h"
#include "./common/GameObject.h"

class Player: public GameObject {
public:
  Player();
  Player(int x, int y);
  ~Player();

public:
  void update(int keyCode) override;
  void render(Graphics& graphics) override;
};