#pragma once

#include "sokoban_function.h"

SearchStat gbfs(State &initial_state);
