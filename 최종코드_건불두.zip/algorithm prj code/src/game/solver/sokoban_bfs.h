#pragma once
#include "sokoban_function.h"

SearchStat bfs(State &initial_state);