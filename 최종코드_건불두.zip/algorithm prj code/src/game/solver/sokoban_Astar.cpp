#include "sokoban_Astar.h"
#include "sokoban_function.h"

SearchStat as(State &initial_state)
{
	std::deque<State> open;
	std::vector<State> closed;
	SearchStat report;
	report.rep_node_count = 0;
	report.fringe_node = 0;
	report.explored_count = 1;//will be replaced, just to stop cout spam
	report.node_count = 1;
	report.node.state_str = "NULL";
	State current_state;
	
	//push first state into queue
	open.push_back(initial_state);
	while (!open.empty())
	{
		//take N from OPEN
		current_state = open.front();
		open.pop_front();
		//push N onto CLOSED
		closed.push_back(current_state);
		
		//print out in case a long time is taken and wondering if it froze
		if ((closed.size() % 5000) == 0)
			{break;
				std::cout << "...explored "<< closed.size() <<" nodes..."<<std::endl;}
			
		//if found, set report node to current node, set explored count to closed list size
		if (is_goal(current_state))
		{
			report.node = current_state;
			report.explored_count = closed.size();
			open.pop_front();
			break;
		}
				
		//generate valid states
		std::queue<State> valid_states;
		valid_states = gen_valid_states(current_state, ASH);
		std::deque<State>::iterator it;
		std::vector<State>::iterator itr;
		
		//while queue is not empty of states
		while (!valid_states.empty())
		{
			bool already_seen = false;
			bool inserted = false;
			State temp_state = valid_states.front();
			//check if state has already been seen on open list
			for (it = open.begin(); it != open.end(); it++)
			{
				if (it->state_str == temp_state.state_str)
				{
					already_seen = true;
					break;
				}
			}
			//check if state has already been seen on closed list
			for (itr = closed.begin(); itr != closed.end(); itr++)
			{
				if (itr->state_str == temp_state.state_str)
				{
					already_seen = true;
					break;
				}
			}
			//if not duplicate, then add state to open queue
			if (!already_seen)
			{
				report.node_count++;
				//add to beginning of node with greater total cost
				//used to maintain generated node order
				for (it = open.begin(); it != open.end(); it++)
				{
					//priority of lowest hscore first
					if (it->hscore > temp_state.hscore)
					{
						open.insert(it, temp_state);
						inserted = true;
						break;
					}
				}
				//if no node has greater priority, push back
				if (!inserted)
					open.push_back(temp_state);
			}
			else
				report.rep_node_count++;
			valid_states.pop();
		}
	}
	report.fringe_node = open.size();
	return report;
} //SearchStat as(State &initial_state, int hfchoice)



