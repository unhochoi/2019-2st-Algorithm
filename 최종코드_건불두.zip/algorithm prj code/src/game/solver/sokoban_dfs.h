#pragma once
#include "sokoban_function.h"

SearchStat dfs(State &initial_state);