#include "sokoban_function.h"
#include "sokoban_heuristic.h"
#include "sokoban_bfs.h"
#include "sokoban_dfs.h"
#include "sokoban_gbfs.h"
#include "sokoban_Astar.h"


bool is_goal(State &cur_state)
{
	//std::cout << cur_state.state_str<<std::endl;
	bool goal = false;
	//if there are no empty goals
	if ((cur_state.state_str.find_first_of('3')) == std::string::npos)
	{
		//if there are no players standing on an empty goal,
		//then we are in goal state
		if ((cur_state.state_str.find_first_of('6')) == std::string::npos)
		{
			//and there are no boxes not on a goal
			if ((cur_state.state_str.find_first_of('2')) == std::string::npos)
				goal = true;
		}
	}
	return goal;
} 


void print_level(std::vector< std::vector<char> > &map)
{
	for (int i = 0; i < map.size(); i++)
	{
		std::vector<char> vec = map[i];
		std::vector<char>::iterator itr;
		for (itr = vec.begin(); itr != vec.end(); itr++)
			std::cout << *itr;
		std::cout << std::endl;
	}
} 


std::queue<State> gen_valid_states (const State &cur_state, const int smode = NONE)
{
	std::queue<State> valid_moves;
	std::stringstream ss(cur_state.state_str);
	std::vector< std::vector<char> > new_level_map;
	State new_state;
	std::string line;
	bool found = false;
	char player, box_move;
	int x, y, counter = 0, MOVE_COST = 1, PUSH_COST = 1;

	std::vector< std::vector<char> > level_map;
	while (getline(ss,line, '\n'))
	{
		std::vector<char> temp;
		level_map.push_back(temp);
		for (int i = 0; i <line.length() ; i++)
		{
			if (!found)
			{
				if (line[i] == '5' | line[i] == '6' )
				{
					player = line[i];
					x = i;
					y = counter;
					found = true;
				}
			}
			level_map[counter].push_back(line[i]);
		}
		counter++;
	}
	if (!found)
	{
		std::cout<<"No player found on level"<<std::endl;
		return valid_moves;
	}
	
    int next_y1, next_y2, next_x1, next_x2;
    std::string dest_arr[4] = {"r, ", "d, ", "l, ", "u, "};
    int xi_arr[4] = {
                    1,  //east
                    0,  //south
                    -1, //west
                    0   //north
                    };
    int yi_arr[4] = {
                    0,  //east
                    1,  //south
                    0,  //west
                    -1  //north
                    };
 
    for(int next_index = 0; next_index <= 3; next_index++){
        next_y1 = y + yi_arr[next_index];
        next_y2 = y + (2*yi_arr[next_index]);
        next_x1 = x + xi_arr[next_index];
        next_x2 = x + (2*xi_arr[next_index]);
        char nextSapce = level_map[next_y1][next_x1];
        switch (nextSapce)
        {
            //move to empty spot
            case '0':
                new_level_map = level_map;
                new_level_map[next_y1][next_x1] = '5';
                (player == '5') ? new_level_map[y][x] = '0' : new_level_map[y][x] = '3';
                
                new_state = cur_state;
                new_state.state_str = "";
                for (int i = 0; i < new_level_map.size(); i++)
                {
                    std::vector<char> temp = new_level_map[i];
                    std::vector<char>::iterator itr;
                    for (itr = temp.begin(); itr != temp.end(); itr++)
                        new_state.state_str.push_back( *itr);
                    new_state.state_str.append("\n");
                }
                
                //update state stats
                new_state.move_list.append(dest_arr[next_index]);
                new_state.depth++;
                new_state.moves++;
                if (smode == GBFSH || smode == ASH){
                    if (smode==ASH) new_state.total_cost += MOVE_COST;
                    new_state.hscore = heuristic(new_state);
                    if(smode==ASH) new_state.hscore += new_state.total_cost;
                }
                valid_moves.push(new_state);
                break;
                
            case '3':
                new_level_map = level_map;
                new_level_map[next_y1][next_x1] = '6';
                (player == '5') ? new_level_map[y][x] = '0' : new_level_map[y][x] = '3';
                
                new_state = cur_state;
                new_state.state_str = "";
                //turning vector<vector<char>> back to string
                for (int i = 0; i < new_level_map.size(); i++)
                {
                    std::vector<char> temp = new_level_map[i];
                    std::vector<char>::iterator itr;
                    for (itr = temp.begin(); itr != temp.end(); itr++)
                        new_state.state_str.push_back( *itr);
                    new_state.state_str.append("\n");
                }
                
                //update state stats
                new_state.move_list.append(dest_arr[next_index]);
                new_state.depth++;
                new_state.moves++;
                if (smode == GBFSH || smode == ASH){
                    if (smode==ASH) new_state.total_cost += MOVE_COST;
                    new_state.hscore = heuristic(new_state);
                    if(smode==ASH) new_state.hscore += new_state.total_cost;
                }
                valid_moves.push(new_state);
                break;
            //move to box on floor
            case '2':
                new_level_map = level_map;
                //adjusting for player tile and tile north of player
                new_level_map[next_y1][next_x1] = '5';
                (player == '5') ? new_level_map[y][x] = '0' : new_level_map[y][x] = '3';
                
                //adjusting for box tile and tile north of box
                box_move = new_level_map[next_y2][next_x2];
                //if north of box is a wall or another box
                if (box_move == '1')
                    break;
                else if (box_move == '2')
                    break;
                else if (box_move == '7')
                    break;
                //if north of box is an empty floor
                else if (box_move == '0')
                {
                    new_level_map[next_y2][next_x2] = '2';
                }
                //if north of box is an empty goal
                else if (box_move == '3')
                {
                    new_level_map[next_y2][next_x2] = '7';
                }
                else
                    break;
                
                //create and update new state
                new_state = cur_state;
                new_state.state_str = "";
                //turning vector<vector<char>> back to string
                for (int i = 0; i < new_level_map.size(); i++)
                {
                    std::vector<char> temp = new_level_map[i];
                    std::vector<char>::iterator itr;
                    for (itr = temp.begin(); itr != temp.end(); itr++)
                        new_state.state_str.push_back( *itr);
                    new_state.state_str.append("\n");
                }
                
                //update state stats
                new_state.move_list.append(dest_arr[next_index]);
                new_state.depth++;
                new_state.pushes++;
                if (smode == GBFSH || smode == ASH){
                    if (smode==ASH) new_state.total_cost += MOVE_COST;
                    new_state.hscore = heuristic(new_state);
                    if(smode==ASH) new_state.hscore += new_state.total_cost;
                }
                valid_moves.push(new_state);
                break;
            //move to box on goal
            case '7':
                new_level_map = level_map;
                //adjusting for player tile and tile north of player
                new_level_map[next_y1][next_x1] = '6';
                (player == '5') ? new_level_map[y][x] = '0' : new_level_map[y][x] = '3';
                
                //adjusting for box tile and tile north of box
                box_move = new_level_map[next_y2][next_x2];
                //if north of box is a wall or another box
                if (box_move == '1')
                    break;
                else if (box_move == '2')
                    break;
                else if (box_move == '7')
                    break;
                //if north of box is an empty floor
                else if (box_move == '0')
                {
                    new_level_map[next_y2][next_x2] = '2';
                }
                //if north of box is an empty goal
                else if (box_move == '3')
                {
                    new_level_map[next_y2][next_x2] = '7';
                }
                else
                    break;
                
                //create and update new state
                new_state = cur_state;
                new_state.state_str = "";
                //turning vector<vector<char>> back to string
                for (int i = 0; i < new_level_map.size(); i++)
                {
                    std::vector<char> temp = new_level_map[i];
                    std::vector<char>::iterator itr;
                    for (itr = temp.begin(); itr != temp.end(); itr++)
                        new_state.state_str.push_back( *itr);
                    new_state.state_str.append("\n");
                }
                
                //update state stats
                new_state.move_list.append(dest_arr[next_index]);
                new_state.depth++;
                new_state.pushes++;
                if (smode == GBFSH || smode == ASH){
                    if (smode==ASH) new_state.total_cost += MOVE_COST;
                    new_state.hscore = heuristic(new_state);
                    if(smode==ASH) new_state.hscore += new_state.total_cost;
                }
                valid_moves.push(new_state);
                break;
            //move to wall
            case '1':
                break;
            default:
                break;
        }
    }


	return valid_moves;
} //std::queue<State> gen_valid_states (const State &cur_state, const int smode = NONE)


int min_arr(int arr[])
{   
    int m = 99999999;
    int idx = -1;
    int ilen = 4;
    for(int i = 0; i < ilen; ++i){
        if (arr[i] < m){
            m = arr[i];
            idx = i;
        }
    }
    return idx;
}

std::string slcing_string(std::string input_str)
{
    std::string output = "";
    int str_length = (int) input_str.length();
    for(int i = 0; i < str_length; ++i){
        char t = (char) input_str[i];
        if(t != ',' && t != ' ')
            output += input_str[i];
    }
    return output;
}

/* Function used to execute a search algorithm on a given initial state.
 *  Reports back search results.
 * 
 * Preconditions: Takes in a state object and an int representing search algo
 * Postconditions:  Executes search algo and prints search stats.
 */
std::string autorun(State &init_state)
{
	int level_size;
	SearchStat dfs_stat, bfs_stat, gbfs_stat, as_stat;
	std::string user_choice;
    std::string dfs_str, bfs_str, gbfs_str, as_str;
    
    dfs_stat = dfs(init_state);
    dfs_str = dfs_stat.node.move_list.substr(0,(dfs_stat.node.move_list.size()-2));
    

    bfs_stat = bfs(init_state);
    bfs_str = bfs_stat.node.move_list.substr(0,(bfs_stat.node.move_list.size()-2));


    gbfs_stat = gbfs(init_state);
    gbfs_str = gbfs_stat.node.move_list.substr(0,(gbfs_stat.node.move_list.size()-2));

    as_stat = as(init_state);
    as_str = as_stat.node.move_list.substr(0,(as_stat.node.move_list.size()-2));


    std::string str_arr[4] = {dfs_str, bfs_str, gbfs_str, as_str};
    int length[4] = {(int) dfs_str.length(), (int) bfs_str.length(), (int) gbfs_str.length(), (int) as_str.length()};
    
    return slcing_string(str_arr[min_arr(length)]);
}
