#include "sokoban_heuristic.h"

int heuristic(const State &cur_state)
{
	std::stringstream ss(cur_state.state_str);
	std::vector< std::vector<int> > box_list;
	std::vector< std::vector<char> > level_map;
	std::string line;
	int score = 0, counter = 0;

	// 레벨 맵을 생성하고 박스가 레벨 맵인 곳을 표시합니다 
	// (y, x) 좌표로 저장되어 라인 단위로 먼저 읽은 다음 (y 평면), char로 char (x 평면)
	while (getline(ss,line, '\n'))
	{
		std::vector<char> temp;
		level_map.push_back(temp);
		for (int i = 0; i <line.length() ; i++)
		{
			// 바닥에 상자가있는 경우 상자 목록에 추가하면 안전하지 않은 위치가 될 수 없으므로 목표의 상자를 무시합니다.
			if (line[i] == '2' )
			{
				std::vector<int> box_loc;
				box_loc.push_back(i);
				box_loc.push_back(counter);
				box_list.push_back(box_loc);
			}
			level_map[counter].push_back(line[i]);
		}
		counter++;
	}

	// 바닥의 각 상자마다 벽 옆에 있는지 확인하고 서로 두 벽에 인접한 경우 모서리입니다.
	for (int i = 0; i < box_list.size(); i++)
	{
		bool N_wall = false;
		bool E_wall = false;
		bool S_wall = false;
		bool W_wall = false;
		bool in_corner = false;
		
		int cur_box_x = box_list[i][0];
		int cur_box_y = box_list[i][1];
		
		//check if there is a wall north of the box
		if (level_map[cur_box_y - 1][cur_box_x] == '1')
			N_wall = true;
		//check if there is a wall east of the box
		if (level_map[cur_box_y][cur_box_x + 1] == '1')
			E_wall = true;
		//check if there is a wall south of the box
		if (level_map[cur_box_y + 1][cur_box_x] == '1')
			S_wall = true;
		//check if there is a wall west of the box
		if (level_map[cur_box_y][cur_box_x - 1] == '1')
			W_wall = true;
		
		// 상자가 모퉁이에 있는지 먼저 확인
		// NE 코너의 체크 박스
		if (N_wall && E_wall)
		{
			in_corner = true;
		}
		//check if box in NW corner
		else if (N_wall && W_wall)
		{
			in_corner = true;
		}
		//check if box in SE corner
		else if (S_wall && E_wall)
		{
			in_corner = true;
		}
		//check if box in SW corner
		else if (S_wall && W_wall)
		{
			in_corner = true;
		}
		
		// 상자가 모서리에 있으면 상자가 교착 상태에 있습니다.
		if (in_corner)
		{
			score += 1000;
		}
		// 상자가 벽 옆에 있으면 벽에 안전하지 않은 모서리 2 개가 있고 벽을 따라 목표가 없는지 벽이 부러지지 않았는지 확인
		else
		{
			// 상자의 북쪽 벽인 경우 가장 동쪽 벽과 서쪽 벽을 검색합니다.
			if (N_wall)
			{
				bool safe = false;
				bool corner_E = false;
				bool corner_W = false;
				
				// 모퉁이가 발견 될 때까지 깨지지 않은 북쪽 벽을 따라 접근 가능한 타일이 있는지 동쪽으로 검색합니다. 
				// 상자와 플레이어는 무시할 수 있고 이동 가능한 타일로 간주됩니다.
				for (int i = cur_box_x + 1; i < level_map[cur_box_y].size(); i++)
				{
					// 길을 따라 목표가 발견되면 안전하지 않은 위치가 될 수 없습니다
					if ((level_map[cur_box_y][i] == '3') ||
					 (level_map[cur_box_y][i] == '7') || (level_map[cur_box_y][i] == '6'))
					{
						safe = true;
						break;
					}
					
					// 북쪽 타일이 벽이 아닌 경우 안전합니다
					if (level_map[cur_box_y - 1][i] != '1')
					{
						safe = true;
						break;
					}
					
					// NE 코너 인 경우
					if ((level_map[cur_box_y][i] == '1') && (level_map[cur_box_y - 1][i] == '1'))
					{
						corner_E = true;
						break;
					}
				}
				
				// 구석을 찾을 때까지 깨지지 않은 북쪽 벽을 따라 접근 가능한 타일이 있는지 서쪽으로 검색합니다. 
				// 상자와 플레이어는 무시할 수 있고 이동 가능한 타일로 간주됩니다.
				for (int i = cur_box_x - 1; i >= 0 ; i--)
				{
					// 길을 따라 목표가 발견되면 안전하지 않은 위치가 될 수 없습니다
					if ((level_map[cur_box_y][i] == '3') ||
					 (level_map[cur_box_y][i] == '7') || (level_map[cur_box_y][i] == '6'))
					{
						safe = true;
						break;
					}
					
					// 북쪽 타일이 벽이 아닌 경우 안전합니다
					if (level_map[cur_box_y - 1][i] != '1')
					{
						safe = true;
						break;
					}
					
					// NW 코너 인 경우
					if ((level_map[cur_box_y][i] == '1') && (level_map[cur_box_y - 1][i] == '1'))
					{
						corner_W = true;
						break;
					}
				}
				
				// 안전하지 않은 위치를 나타 내기 위해 목표 증가 점수로 상자의 동쪽과 서쪽 경로를 따라 구석으로 벽이 깨지지 않은 경우
				if (!safe)
				{
					if(corner_E && corner_W)
						score += 1000;
				}	
			}
			
			// 상자의 벽이 북쪽이면 벽의 최북단과 최남단을 검색합니다.
			if (E_wall)
			{
				bool safe = false;
				bool corner_N = false;
				bool corner_S = false;
				
				// 모퉁이가 발견 될 때까지 깨지지 않은 동쪽 벽을 따라 접근 가능한 타일이 있는지 북쪽으로 검색합니다. 
				// 상자와 플레이어는 무시할 수 있고 이동 가능한 타일로 간주됩니다.
				for (int i = cur_box_y - 1; i >=0; i--)
				{
					// 길을 따라 목표가 발견되면 안전하지 않은 위치가 될 수 없습니다
					if ((level_map[i][cur_box_x] == '3') ||
					 (level_map[i][cur_box_x] == '7') || (level_map[i][cur_box_x] == '6'))
					{
						safe = true;
						break;
					}
					
					// 동쪽 타일이 벽이 아닌 경우 안전합니다
					if (level_map[i][cur_box_x + 1] != '1')
					{
						safe = true;
						break;
					}
					
					//if NE corner
					if ((level_map[i][cur_box_x] == '1') && (level_map[i][cur_box_x + 1] == '1'))
					{
						corner_N = true;
						break;
					}
				}
				
				// 모퉁이가 발견 될 때까지 깨지지 않은 동쪽 벽을 따라 접근 가능한 타일이 있는지 남쪽으로 검색합니다. 
				// 상자와 플레이어는 무시할 수 있고 이동 가능한 타일로 간주됩니다.
				for (int i = cur_box_y + 1; i < level_map.size(); i++)
				{
					// 길을 따라 목표가 발견되면 안전하지 않은 위치가 될 수 없습니다
					if ((level_map[i][cur_box_x] == '3') ||
					 (level_map[i][cur_box_x] == '7') || (level_map[i][cur_box_x] == '6'))
					{
						safe = true;
						break;
					}
					
					// 동쪽 타일이 벽이 아닌 경우 안전합니다
					if (level_map[i][cur_box_x + 1] != '1')
					{
						safe = true;
						break;
					}
					
					// SE 코너 인 경우
					if ((level_map[i][cur_box_x] == '1') && (level_map[i][cur_box_x + 1] == '1'))
					{
						corner_S = true;
						break;
					}
				}
				
				// 안전하지 않은 위치를 나타 내기 위해 목표 증가 점수로 상자의 동쪽과 서쪽 경로를 따라 구석으로 벽이 깨지지 않은 경우
				if (!safe)
				{
					if(corner_N && corner_S)
						score += 1000;
				}	
			}
			
			//if wall south of box, search for and east-most and west-most wall
			if (S_wall)
			{
				bool safe = false;
				bool corner_E = false;
				bool corner_W = false;
				
				//search east to see if there are accessible tiles along unbroken
				//south walls until a corner is found.  boxes and players are ignored
				//and considered accessible tiles since they can move
				for (int i = cur_box_x + 1; i < level_map[cur_box_y].size(); i++)
				{
					//if goal is found along the way then it cannot be an unsafe position
					if ((level_map[cur_box_y][i] == '3') ||
					 (level_map[cur_box_y][i] == '7') || (level_map[cur_box_y][i] == '6'))
					{
						safe = true;
						break;
					}
					
					//if south tile is not a wall, then it is safe
					if (level_map[cur_box_y + 1][i] != '1')
					{
						safe = true;
						break;
					}
					
					//if SE corner
					if ((level_map[cur_box_y][i] == '1') && (level_map[cur_box_y + 1][i] == '1'))
					{
						corner_E = true;
						break;
					}
				}
				
				//search west to see if there are accessible tiles along unbroken
				//south walls until a corner is found.  boxes and players are ignored
				//and considered accessible tiles since they can move
				for (int i = cur_box_x - 1; i >= 0 ; i--)
				{
					//if goal is found along the way then it cannot be an unsafe position
					if ((level_map[cur_box_y][i] == '3') ||
					 (level_map[cur_box_y][i] == '7') || (level_map[cur_box_y][i] == '6'))
					{
						safe = true;
						break;
					}
					
					//if south tile is not a wall, then it is safe
					if (level_map[cur_box_y + 1][i] != '1')
					{
						safe = true;
						break;
					}
					
					//if SW corner
					if ((level_map[cur_box_y][i] == '1') && (level_map[cur_box_y + 1][i] == '1'))
					{
						corner_W = true;
						break;
					}
				}
				
				//if unbroken wall along path east and west of the box to corners with any goal
				//increment score to signify unsafe position
				if (!safe)
				{
					if(corner_E && corner_W)
						score += 1000;
				}	
			}
			
			//if wall north of box, search for and north-most and south-most wall
			if (W_wall)
			{
				bool safe = false;
				bool corner_N = false;
				bool corner_S = false;
				
				//search north to see if there are accessible tiles along unbroken
				//east walls until a corner is found.  boxes and players are ignored
				//and considered accessible tiles since they can move
				for (int i = cur_box_y - 1; i >=0; i--)
				{
					//if goal is found along the way then it cannot be an unsafe position
					if ((level_map[i][cur_box_x] == '3') ||
					 (level_map[i][cur_box_x] == '7') || (level_map[i][cur_box_x] == '6'))
					{
						safe = true;
						break;
					}
					
					//if east tile is not a wall, then it is safe
					if (level_map[i][cur_box_x - 1] != '1')
					{
						safe = true;
						break;
					}
					
					//if NW corner
					if ((level_map[i][cur_box_x] == '1') && (level_map[i][cur_box_x - 1] == '1'))
					{
						corner_N = true;
						break;
					}
				}
				
				// 모퉁이가 발견 될 때까지 깨지지 않은 동쪽 벽을 따라 접근 가능한 타일이 있는지 남쪽으로 검색합니다. 
				// 상자와 플레이어는 무시할 수 있고 이동 가능한 타일로 간주됩니다.
				for (int i = cur_box_y + 1; i < level_map.size(); i++)
				{
					//if goal is found along the way then it cannot be an unsafe position
					if ((level_map[i][cur_box_x] == '3') ||
					 (level_map[i][cur_box_x] == '7') || (level_map[i][cur_box_x] == '6'))
					{
						safe = true;
						break;
					}
					
					//if east tile is not a wall, then it is safe
					if (level_map[i][cur_box_x - 1] != '1')
					{
						safe = true;
						break;
					}
					
					//if SW corner
					if ((level_map[i][cur_box_x] == '1') && (level_map[i][cur_box_x - 1] == '1'))
					{
						corner_S = true;
						break;
					}
				}
				
				//if unbroken wall along path east and west of the box to corners with any goal
				//increment score to signify unsafe position
				if (!safe)
				{
					if(corner_N && corner_S)
						score += 1000;
				}	
			}
		}
	}
	return score;
} //int h2(const State &cur_state)

