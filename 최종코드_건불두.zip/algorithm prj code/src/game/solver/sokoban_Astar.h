#pragma once
#include "sokoban_function.h"

SearchStat as(State &initial_state);
