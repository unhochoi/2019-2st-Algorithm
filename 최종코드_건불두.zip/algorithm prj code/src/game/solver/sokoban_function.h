#pragma once
#include <sys/time.h>
#include <iostream>
#include <cstdlib>
#include <sstream>
#include <vector>
#include <queue>
#include <deque>
#include <string>
#include <fstream>


enum search_mode {NONE, BFS, DFS, GBFSH, ASH};

/* States contain the level, how many moves/pushes and move list to get
 * to that state, and how deep that state is in node terms
 */
struct State
{
	std::string state_str;  
	std::string move_list;
	int depth;
	int moves;
	int pushes;
	int total_cost;
	int hscore;
}; //struct State


struct SearchStat
{
	State node;
	int node_count;
	int rep_node_count;
	int fringe_node;
	int explored_count;
}; //struct SearchStat

bool is_goal(State &cur_state);
void print_level(std::vector< std::vector<char> > &map);
std::queue<State> gen_valid_states(const State &cur_state, const int smode);

std::string autorun(State &init_state);
int min_arr(int arr[]);


