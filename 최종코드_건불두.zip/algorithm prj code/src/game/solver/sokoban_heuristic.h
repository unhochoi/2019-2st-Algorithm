#include "sokoban_function.h"

int heuristic(const State &cur_state);
