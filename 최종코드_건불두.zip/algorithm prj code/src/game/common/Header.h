#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <clocale>
#include <stack>
#include <chrono>
#include <thread>

#include <ncurses.h>

#include "Movement.h"

#define MAP_WIDTH 40
#define MAP_HEIGHT 20

#define MAX_STAGE 2

#define DOWN_KEY 258
#define UP_KEY 259
#define LEFT_KEY 260
#define RIGHT_KEY 261

#define ENTER_KEY 13
#define RESET_KEY 114
#define UNDO_KEY 122
#define SOLVE_KEY 83, 115
 
enum class Block {
  None,
  Wall,
  Box,
  Trigger,
  Empty,
  Spawner
};

enum class Direction {
  Down,
  Up,
  Left,
  Right
};

inline Direction getDirectionFromKeyCode(int keyCode) {
  return static_cast<Direction>(keyCode - 258);
}

inline void getPointFromDirection(Direction d, int& x, int& y) {
  switch (d)
  {
  case Direction::Up:
    y -= 1;
    break;
  case Direction::Down:
    y += 1;
    break;
  case Direction::Left:
    x -= 1;
    break;
  case Direction::Right:
    x += 1;
    break;
  }
}
