#include "Graphics.h"

Graphics::Graphics() {
    setlocale(LC_ALL, "");

    initscr();

    // ! FIXME: MacOS에서 동작하지 않음
    resize_term(100, 100);

    // Create Windows
    gameWindow = newwin(22, 42, 0, 0);
    uiWindow = newwin(22, 22, 0, 42);
    solverWindow = newwin(3, 64, 21, 0);

    // Set No Eacho
    noecho();

    // Set Color Mode
    start_color();

    // Remove Cursor
    curs_set(0);

    // Set Color Pair
    init_pair(1, COLOR_BLACK, COLOR_WHITE);
    init_pair(2, COLOR_WHITE, COLOR_WHITE);
    init_pair(3, COLOR_GREEN, COLOR_GREEN);
    init_pair(4, COLOR_WHITE, COLOR_BLUE);
    init_pair(5, COLOR_RED, COLOR_CYAN);
    init_pair(7, COLOR_CYAN, COLOR_MAGENTA);
    init_pair(8, COLOR_WHITE, COLOR_BLACK);

    // Set Use Keyboard
    keypad(stdscr, TRUE);
}

Graphics::~Graphics() {
    delwin(gameWindow);
    delwin(uiWindow);
    delwin(solverWindow);
}

void Graphics::begin() {
    wclear(gameWindow);
    wclear(uiWindow);
    wclear(solverWindow);

    wattron(gameWindow, COLOR_PAIR(5));
    wborder(gameWindow, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ');
    wattroff(gameWindow, COLOR_PAIR(5));
    wattron(uiWindow, COLOR_PAIR(5));
    wborder(uiWindow, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ');
    wattroff(uiWindow, COLOR_PAIR(5));
    wattron(solverWindow, COLOR_PAIR(5));
    wborder(solverWindow, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ');
    wattroff(solverWindow, COLOR_PAIR(5));
}

void Graphics::end() {
    wrefresh(gameWindow);
    wrefresh(solverWindow);
    wrefresh(uiWindow);
}

WINDOW *Graphics::getWindowByType(GraphicsType type) {
    WINDOW *targetWindow = nullptr;

    switch (type) {
        case GraphicsType::GameObject:
            targetWindow = gameWindow;
            break;
        case GraphicsType::UI:
            targetWindow = uiWindow;
            break;
        case GraphicsType::Solver:
            targetWindow = solverWindow;
            break;
        default:
            targetWindow = stdscr;
            break;
    }

    return targetWindow;
}

void Graphics::render(GraphicsType type, const std::string &text, int x, int y) {
    render(type, text, x, y, 0, false, false);
}

void Graphics::render(GraphicsType type, const std::string &text, int x, int y, int color, bool bold, bool underline) {
    WINDOW *targetWindow = getWindowByType(type);

    if (bold) {
        wattron(targetWindow, A_BOLD);
    }

    if (underline) {
        wattron(targetWindow, A_UNDERLINE);
    }

    wattron(targetWindow, COLOR_PAIR(color));

    mvwprintw(targetWindow, y, x, text.c_str());

    if (bold) {
        wattroff(targetWindow, A_BOLD);
    }

    if (underline) {
        wattroff(targetWindow, A_UNDERLINE);
    }

    wattroff(targetWindow, COLOR_PAIR(color));
}

void Graphics::render(GraphicsType type, const std::string &text, int x, int y, int color, bool blink) {
    WINDOW *targetWindow = getWindowByType(type);

    if (blink) {
        wattron(targetWindow, A_BLINK);
    }

    wattron(targetWindow, COLOR_PAIR(color));

    mvwprintw(targetWindow, y, x, text.c_str());

    if (blink) {
        wattroff(targetWindow, A_BLINK);
    }

    wattroff(targetWindow, COLOR_PAIR(color));
}
