#pragma once
#include "Header.h"
#include "Graphics.h"

class Graphics;
class GameObject {
public:
  int x;
  int y;

public:
  GameObject();
  virtual ~GameObject();

public:
  virtual void update(int keyCode);
  virtual void render(Graphics& graphics);
};