#pragma once

#include "./Header.h"

enum GraphicsType {
    GameObject,
    UI,
    Solver
};

class Graphics {
private:
    WINDOW *gameWindow;
    WINDOW *uiWindow;
    WINDOW *solverWindow;

public:
    Graphics();

    ~Graphics();

public:
    void begin();

    void end();

private:
    WINDOW *getWindowByType(GraphicsType type);

public:
    void render(GraphicsType type, const std::string &text, int x, int y);

    void render(GraphicsType type, const std::string &text, int x, int y, int color, bool bold, bool underline);

    void render(GraphicsType type, const std::string &text, int x, int y, int color, bool blink);
};