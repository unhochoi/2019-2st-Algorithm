#include "GameObject.h"

GameObject::GameObject(): x(0), y(0) {
}

GameObject::~GameObject() {
}

void GameObject::update(int keyCode) {
}

void GameObject::render(Graphics& graphics) {
}