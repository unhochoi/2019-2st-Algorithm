#include "./common/Graphics.h"
#include "./Map.h"
#include "./Player.h"
#include <deque>
#include <unistd.h>
class Game {
private:
  Graphics graphics;

private:
  Map** originalMaps;
  Map* map;
  int currentStage;
  std::deque<char> solve_char;

private:
  Player* player;
  std::stack<std::pair<Movement, bool>> moveHistory;

private:
  int playerStepCount;
  int boxPushCount;

private:
  bool showStage;

public:
  Game(int argc, char*argv);
  ~Game();

private:
  void loadStage(int stageLevel);

private:
  void undo();
  void reset();

private:
  void update(int keyCode);
  void render();

public:
  void run();
  std::string solver(std::string path);
};
