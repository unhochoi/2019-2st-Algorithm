#include "Game.h"
#include "solver/sokoban_dfs.h"
#include "solver/sokoban_function.h"
#include "solver/sokoban_Astar.h"
#include "solver/sokoban_gbfs.h"

std::string solve_path[MAX_STAGE];
std::string mode="user";

Game::Game(int argc, char*argv) {
    // 스테이지 불러오기
    graphics.begin();
    graphics.render(GraphicsType::GameObject, "LOADING" , 17, 6, 3, true, false);
    


    graphics.render(GraphicsType::GameObject, "    ", 10, 13, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 10, 14, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 13, 14, 7, true);
    graphics.render(GraphicsType::GameObject, "    ", 10, 15, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 10, 16, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 10, 17, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 10, 18, 7, true);

    graphics.render(GraphicsType::GameObject, " ", 15, 13, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 15, 14, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 15, 15, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 15, 16, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 15, 17, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 15, 18, 7, true);
    graphics.render(GraphicsType::GameObject, "    ", 16, 18, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 19, 13, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 19, 14, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 19, 15, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 19, 16, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 19, 17, 7, true);

    graphics.render(GraphicsType::GameObject, "     ", 21, 13, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 21, 14, 7, true);
    graphics.render(GraphicsType::GameObject, "     ", 21, 15, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 25, 16, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 25, 17, 7, true);
    graphics.render(GraphicsType::GameObject, "     ", 21, 18, 7, true);

    graphics.render(GraphicsType::GameObject, " ", 27, 13, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 27, 14, 7, true);
    graphics.render(GraphicsType::GameObject, "     ", 27, 15, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 27, 16, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 27, 17, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 27, 18, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 31, 13, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 31, 14, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 31, 15, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 31, 16, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 31, 17, 7, true);
    graphics.render(GraphicsType::GameObject, " ", 31, 18, 7, true);
    graphics.end();
  
    
    originalMaps = new Map *[argc]();
    for (int i = 1; i <= argc; i++) {
        std::string path(argv);
        
        path.append(std::to_string(i));
        originalMaps[i] = new Map(path);
        solve_path[i-1]= solver(path);
    }

    this->player = new Player();

    loadStage(1);
}

std::string Game::solver(std::string path) {
    int level_size;
	bool repeat = true;
	std::string usr_input;
	std::ifstream fs;
	std::string line;
	std::string input_level = "";

	//checks if argument exists, can't input level if no txt file
	
	fs.open(path);
	if (!fs)
	{
        
		std::cerr << "  error opening file " << path
			<< std::endl;
		return 0;
	}
	
	//get size of array from first line of input level
	std::getline(fs, line, '\n');
	std::getline(fs, line, '\n');
	level_size = atoi(line.c_str());
	

	//append lines to string
	while (std::getline(fs, line))
	{
		input_level.append(line) += "\n";

	}
	fs.close();
	
	State init_state;
	init_state.state_str = input_level; //map input String 
	init_state.move_list = "";
	init_state.moves = init_state.pushes =
	init_state.total_cost = init_state.depth =
	init_state.hscore = 0;
    std::string receive_str;


    receive_str = autorun(init_state);
    return receive_str;
}

Game::~Game() {
    delete player;
    delete map;
}

void Game::update(int keyCode) {
    if (showStage) {
        showStage = false;
        return;
    }

    bool isResetInput = (keyCode == RESET_KEY);
    if (isResetInput) {
        reset();
        return;
    }

    bool isUndo = (keyCode == UNDO_KEY);
    if (isUndo) {
        undo();
        return;
    }

    //S key input 
    if (keyCode == (int)'S' || keyCode == (int)'s'){
        for(int i =0; i < solve_path[currentStage-1].length(); i++){
        solve_char.push_back(solve_path[currentStage-1][i]);
    }
        mode = "solver";
        reset();
    }

    bool isMove = (keyCode >= 258) && (keyCode <= 261);
    if (isMove) {
        Direction d = static_cast<Direction>(keyCode - 258);

        int dx = 0, dy = 0;
        getPointFromDirection(d, dx, dy);

        bool pushed = false;

        if (map->isPushable(player->x + dx, player->y + dy, d)) {
            map->push(player->x + dx, player->y + dy, d);
            boxPushCount += 1;
            pushed = true;
        }

        if (map->isMoveable(player->x + dx, player->y + dy)) {
            Movement movement(player->x, player->y, player->x + dx, player->y + dy);
            moveHistory.push(std::pair<Movement, bool>(movement, pushed));

            player->update(keyCode);
            playerStepCount += 1;
        }
    }

    if (map->isClear()) {
        render();
        usleep(1000000);
        mode = "user";
        int nextStage = (currentStage < MAX_STAGE) ? currentStage + 1 : 0;
        loadStage(nextStage);
    }
}

void Game::render() {
    graphics.begin();

    if (showStage) {
        graphics.render(GraphicsType::GameObject, "GAME STAGE " + std::to_string(currentStage), 15, 6, 1, true, false);
        graphics.render(GraphicsType::GameObject, "PRESS ANY KEY TO START", 10, 10, 8, true);


        graphics.render(GraphicsType::GameObject, "    ", 10, 13, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 10, 14, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 13, 14, 7, true);
        graphics.render(GraphicsType::GameObject, "    ", 10, 15, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 10, 16, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 10, 17, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 10, 18, 7, true);

        graphics.render(GraphicsType::GameObject, " ", 15, 13, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 15, 14, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 15, 15, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 15, 16, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 15, 17, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 15, 18, 7, true);
        graphics.render(GraphicsType::GameObject, "    ", 16, 18, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 19, 13, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 19, 14, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 19, 15, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 19, 16, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 19, 17, 7, true);

        graphics.render(GraphicsType::GameObject, "     ", 21, 13, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 21, 14, 7, true);
        graphics.render(GraphicsType::GameObject, "     ", 21, 15, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 25, 16, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 25, 17, 7, true);
        graphics.render(GraphicsType::GameObject, "     ", 21, 18, 7, true);

        graphics.render(GraphicsType::GameObject, " ", 27, 13, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 27, 14, 7, true);
        graphics.render(GraphicsType::GameObject, "     ", 27, 15, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 27, 16, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 27, 17, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 27, 18, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 31, 13, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 31, 14, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 31, 15, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 31, 16, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 31, 17, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 31, 18, 7, true);
        graphics.end();
        return;
    }

    map->render(graphics);
    player->render(graphics);
    graphics.render(GraphicsType::UI, "____________________", 1, 3, 0, true, true);
    graphics.render(GraphicsType::UI, "````````````````````", 1, 4, 0, true, false);
    graphics.render(GraphicsType::UI, "____________________", 1, 6, 0, true, true);
    graphics.render(GraphicsType::UI, "````````````````````", 1, 7, 0, true, false);
    graphics.render(GraphicsType::UI, "____________________", 1, 9, 0, true, true);
    graphics.render(GraphicsType::UI, "````````````````````", 1, 10, 0, true, false);
    graphics.render(GraphicsType::UI, "____________________", 1, 12, 0, true, true);
    graphics.render(GraphicsType::UI, "````````````````````", 1, 13, 0, true, false);
    graphics.render(GraphicsType::UI, "____________________", 1, 15, 0, true, true);
    graphics.render(GraphicsType::UI, "````````````````````", 1, 16, 0, true, false);
    graphics.render(GraphicsType::UI, "|", 13, 4, 0, true, false);
    graphics.render(GraphicsType::UI, "|", 13, 5, 0, true, false);
    graphics.render(GraphicsType::UI, "|", 13, 6, 0, true, false);
    graphics.render(GraphicsType::UI, "|", 13, 7, 0, true, false);
    graphics.render(GraphicsType::UI, "|", 13, 8, 0, true, false);
    graphics.render(GraphicsType::UI, "|", 13, 9, 0, true, false);
    graphics.render(GraphicsType::UI, "|", 13, 10, 0, true, false);
    graphics.render(GraphicsType::UI, "|", 13, 11, 0, true, false);
    graphics.render(GraphicsType::UI, "|", 13, 12, 0, true, false);
    graphics.render(GraphicsType::UI, "|", 13, 13, 0, true, false);
    graphics.render(GraphicsType::UI, "|", 13, 14, 0, true, false);
    graphics.render(GraphicsType::UI, "|", 13, 15, 0, true, false);


    graphics.render(GraphicsType::UI, "SOKOBAN", 8, 2, 0, true, true);


    graphics.render(GraphicsType::UI, "GAME STAGE", 2, 5);
    graphics.render(GraphicsType::UI, std::to_string(currentStage), 19, 5);

    graphics.render(GraphicsType::UI, "STEPS", 2, 8, 8, false, false);
    graphics.render(GraphicsType::UI, std::to_string(playerStepCount), 19, 8);

    graphics.render(GraphicsType::UI, "PUSH", 2, 11, 8, false, false);
    if (mode == "solver"){
        std::string temp_string="";
        for ( int i =0 ; i< solve_char.size() && i<55; i++) {
            temp_string+=solve_char[i];
        } 
        graphics.render(GraphicsType::Solver, "PATH: " + temp_string, 1, 1, 8, true, false);
    }
    else{
        graphics.render(GraphicsType::Solver, "Press 'S' key for change to solver mode", 1, 1, 8, true, false);
    }
    
    graphics.render(GraphicsType::UI, std::to_string(boxPushCount), 19, 11);
    graphics.render(GraphicsType::UI, "STATUS", 2, 14, 8, false, false);
    graphics.render(GraphicsType::UI, "2019-ALGO", 6, 18, 8, false, false);
    graphics.render(GraphicsType::UI, "GUNBULLDO", 6, 19, 8, false, false);


    if (map->isClear()) {
        graphics.render(GraphicsType::UI, "CLEAR", 16, 14);
    } else {
        graphics.render(GraphicsType::UI, "PLAY", 16, 14);
    }

    graphics.end();
}

void Game::loadStage(int stageLevel) {
    if(stageLevel == 0){
        graphics.begin();
        graphics.render(GraphicsType::GameObject, "FINISH" , 17, 6, 3, true, false);
        
        graphics.render(GraphicsType::GameObject, "    ", 10, 13, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 10, 14, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 13, 14, 7, true);
        graphics.render(GraphicsType::GameObject, "    ", 10, 15, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 10, 16, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 10, 17, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 10, 18, 7, true);

        graphics.render(GraphicsType::GameObject, " ", 15, 13, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 15, 14, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 15, 15, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 15, 16, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 15, 17, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 15, 18, 7, true);
        graphics.render(GraphicsType::GameObject, "    ", 16, 18, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 19, 13, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 19, 14, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 19, 15, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 19, 16, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 19, 17, 7, true);

        graphics.render(GraphicsType::GameObject, "     ", 21, 13, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 21, 14, 7, true);
        graphics.render(GraphicsType::GameObject, "     ", 21, 15, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 25, 16, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 25, 17, 7, true);
        graphics.render(GraphicsType::GameObject, "     ", 21, 18, 7, true);

        graphics.render(GraphicsType::GameObject, " ", 27, 13, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 27, 14, 7, true);
        graphics.render(GraphicsType::GameObject, "     ", 27, 15, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 27, 16, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 27, 17, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 27, 18, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 31, 13, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 31, 14, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 31, 15, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 31, 16, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 31, 17, 7, true);
        graphics.render(GraphicsType::GameObject, " ", 31, 18, 7, true);
        graphics.end();
        sleep(99999999);
        
    }
    this->currentStage = stageLevel;
    this->playerStepCount = 0;
    this->boxPushCount = 0;

    const Map *originalStage = this->originalMaps[this->currentStage];
    this->map = new Map(*originalStage);

    // * 이동 기록 삭제
    while (!this->moveHistory.empty()) {
        this->moveHistory.pop();
    }

    this->player->x = this->map->startX;
    this->player->y = this->map->startY;

    this->showStage = true;
}

void Game::run() {
    render();
    
    while(1){
        while (mode == "user") {
            int keyCode = getch();
            update(keyCode);
            render();
        }
        while(mode == "solver"){
            char keyCode = solve_char.front();
            solve_char.pop_front();
            switch(keyCode){
                case 'l':
                    update(LEFT_KEY);
                    break;
                case 'u':
                    update(UP_KEY);
                    break;
                case 'r':
                    update(RIGHT_KEY);
                    break;
                case 'd':
                    update(DOWN_KEY);
                    break;

            }
            render();
            usleep(300000);
            if(solve_char.empty()){
                mode = "user";
                break;
            }
        }
    }
}

void Game::undo() {
    if (!moveHistory.empty()) {
        std::pair<Movement, bool> moveData = moveHistory.top();
        player->x = moveData.first.fromX;
        player->y = moveData.first.fromY;

        // * 이동하면서 박스를 밀었다면 박스를 1단계 이전 상태로 돌림
        if (moveData.second) {
            map->undo();
        }

        moveHistory.pop();
    }
}

void Game::reset() {
    playerStepCount = 0;
    boxPushCount = 0;

    while (!moveHistory.empty()) {
        undo();
    }
}
