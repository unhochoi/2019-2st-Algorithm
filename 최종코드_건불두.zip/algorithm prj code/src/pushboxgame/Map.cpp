#include "Map.h"
#include <algorithm>

Map::Map(const std::string& fileName)
: width(0), height(0), startX(0), startY(0), offsetX(0), offsetY(0) {
  std::ifstream fs(fileName);
  fs >> width >> height;

  map = new int*[height];
  for (int i = 0; i < height; i++) {
    map[i] = new int[width];
    for (int j = 0; j < width; j++) {
      map[i][j] = 0;
    }
  }

  boxMap = new int*[height];
  for (int i = 0; i < height; i++) {
    boxMap[i] = new int[width];
    for (int j = 0; j < width; j++) {
      boxMap[i][j] = 0;
    }
  }

  offsetX = (MAP_WIDTH / 2) - (width / 2) + 1;
  offsetY = (MAP_HEIGHT / 2) - (height / 2) + 1;

  std::string line = "";

  int i = 0;
  while (std::getline(fs, line)) {

    if (line.length() == 0)
      continue;
    std::string temp_string = line;
    line = "";
    for (int j = 0; j < temp_string.size() ; j++){
        if (temp_string[j] == ' ') continue;
        line+=temp_string[j];
    }

    //line.erase(std::find(line.begin(), line.end(), ' ')); 
    
    for (int j = 0; j < width; j++) {
      Block block = static_cast<Block>(line.at(j) - 48);
      switch (block)
      {
      case Block::Box:
        boxMap[i][j] = 1;
        block = Block::None;
        break;
      case Block::Spawner:
        startX = j + offsetX;
        startY = i + offsetY;
        block = Block::None;
        break;
      default:
        break;
      }

      map[i][j] = (int)block;
    }

    i += 1;
  }
}

Map::Map(const Map& map){
  this->width = map.width;
  this->height = map.height;

  this->offsetX = (MAP_WIDTH / 2) - (width / 2) + 1;
  this->offsetY = (MAP_HEIGHT / 2) - (height / 2) + 1;
  
  this->startX = map.startX;
  this->startY = map.startY;

  this->map = new int*[height];
  for (int i = 0; i < height; i++) {
    this->map[i] = new int[width];
    for (int j = 0; j < width; j++) {
      this->map[i][j] = map.map[i][j];
    }
  }

  boxMap = new int*[height];
  for (int i = 0; i < height; i++) {
    boxMap[i] = new int[width];
    for (int j = 0; j < width; j++) {
      boxMap[i][j] = map.boxMap[i][j];
    }
  }
}

Map::~Map() {
  for (int i = 0; i < height; i++) {
    delete map[i];
  }
  delete map;
}

void Map::draw(GUIWindow& GUIWindow) {
  for (int i = 0; i < height; i++) {
    for (int j = 0; j < width; j++) {
      std::string text = "";
      int color = 0;
      bool bold = false;

      Block block = static_cast<Block>(map[i][j]);
      if (boxMap[i][j] == 1) {
        block = Block::Box;
      }

      switch (block)
      {
      case Block::Wall:
        text = "#";
        color = 2;
        break;
      case Block::Box:
        text = "@";
        color = 3;
        bold = true;
        break;
      case Block::Trigger:
        text = "O";
        color = 4;
        break;
      default:
        text = " ";
        break;
      }

      int x = j + offsetX;
      int y = i + offsetY;

      GUIWindow.draw(GUIWindowType::PushBoxGameObject, text, x, y, color, bold, false);
    }
  }
}


int Map::getBlock(int x, int y) {
  return map[y - offsetY][x - offsetX];
}

void Map::setBlock(int x, int y, int block) {
  map[y - offsetY][x - offsetX] = block;
}

int Map::getBoxBlock(int x, int y) {
  return boxMap[y - offsetY][x - offsetX];
}

void Map::setBoxBlock(int x, int y, int block) {
  boxMap[y - offsetY][x - offsetX] = block;
}

bool Map::isMoveable(int x, int y) {
  if (getBoxBlock(x, y) == 1) {
    return false;
  }

  Block block = static_cast<Block>(getBlock(x, y));
  if (block == Block::Wall) {
    return false;
  }

  return true;
}

bool Map::isPushable(int x, int y, Direction d) {
  if (getBoxBlock(x, y) == 0) {
    return false;
  }

  int dx = 0, dy = 0;
  getPointFromDirection(d, dx, dy);

  int nextBox = getBoxBlock(x + dx, y + dy);
  if (nextBox != 0) {
    return false;
  }

  Block nextBlock = static_cast<Block>(getBlock(x + dx, y + dy));
  if (nextBlock == Block::None || nextBlock == Block::Trigger) {
    return true;
  }

  return false;
}

bool Map::isClear() {
  bool isClear = true;

  for (int i = 0; i < height; i++) {
    for (int j = 0; j < width; j++) {
      if (boxMap[i][j] == 1) {
        isClear &= static_cast<Block>(map[i][j]) == Block::Trigger;
      }
    }
  }

  return isClear;
}

void Map::push(int x, int y, Direction d) {
  int dx = 0, dy = 0;
  getPointFromDirection(d, dx, dy);

  Movement movement(x, y, x + dx, y + dy);
  pushHistorys.push(movement);

  setBoxBlock(x, y, 0);
  setBoxBlock(x + dx, y + dy, 1);
}

void Map::undo() {
  if(!pushHistorys.empty()) {
    Movement movement = pushHistorys.top();
    setBoxBlock(movement.toX, movement.toY, 0);
    setBoxBlock(movement.fromX, movement.fromY, 1);
    pushHistorys.pop();
  }
}