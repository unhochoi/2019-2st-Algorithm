#include "GUIWindow.h"

GUIWindow::GUIWindow() {
    setlocale(LC_ALL, "");

    initscr();

    resize_term(100, 100);

    gameWindow = newwin(22, 42, 0, 0);
    uiWindow = newwin(22, 22, 0, 42);
    solverWindow = newwin(3, 64, 21, 0);

    // Set No Eacho
    noecho();

    // Set Color Mode
    start_color();

    // Remove Cursor
    curs_set(0);

    // Set Color Pair
    init_pair(1, COLOR_BLACK, COLOR_WHITE);
    init_pair(2, COLOR_WHITE, COLOR_WHITE);
    init_pair(3, COLOR_GREEN, COLOR_GREEN);
    init_pair(4, COLOR_WHITE, COLOR_BLUE);
    init_pair(5, COLOR_RED, COLOR_CYAN);
    init_pair(7, COLOR_CYAN, COLOR_MAGENTA);
    init_pair(8, COLOR_WHITE, COLOR_BLACK);

    // Set Use Keyboard
    keypad(stdscr, TRUE);
}

GUIWindow::~GUIWindow() {
    delwin(gameWindow);
    delwin(uiWindow);
    delwin(solverWindow);
}

void GUIWindow::begin() {
    wclear(gameWindow);
    wclear(uiWindow);
    wclear(solverWindow);

    wattron(gameWindow, COLOR_PAIR(5));
    wborder(gameWindow, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ');
    wattroff(gameWindow, COLOR_PAIR(5));
    wattron(uiWindow, COLOR_PAIR(5));
    wborder(uiWindow, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ');
    wattroff(uiWindow, COLOR_PAIR(5));
    wattron(solverWindow, COLOR_PAIR(5));
    wborder(solverWindow, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ');
    wattroff(solverWindow, COLOR_PAIR(5));
}

void GUIWindow::end() {
    wrefresh(gameWindow);
    wrefresh(solverWindow);
    wrefresh(uiWindow);
}

WINDOW *GUIWindow::getWindowByType(GUIWindowType type) {
    WINDOW *targetWindow = nullptr;

    if (type == GUIWindowType::PushBoxGameObject) {
        targetWindow = gameWindow;
    } else if (type == GUIWindowType::UI) {
        targetWindow = uiWindow;
    } else if (type == GUIWindowType::Solver) {
        targetWindow = solverWindow;
    }

    return targetWindow;
}

void GUIWindow::draw(GUIWindowType type, const std::string &text, int x, int y) {
    draw(type, text, x, y, 0, false, false);
}

void GUIWindow::draw(GUIWindowType type, const std::string &text, int x, int y, int color, bool bold, bool underline) {
    WINDOW *targetWindow = getWindowByType(type);

    if (bold) {
        wattron(targetWindow, A_BOLD);
    }

    if (underline) {
        wattron(targetWindow, A_UNDERLINE);
    }

    wattron(targetWindow, COLOR_PAIR(color));

    mvwprintw(targetWindow, y, x, text.c_str());

    if (bold) {
        wattroff(targetWindow, A_BOLD);
    }

    if (underline) {
        wattroff(targetWindow, A_UNDERLINE);
    }

    wattroff(targetWindow, COLOR_PAIR(color));
}

void GUIWindow::draw(GUIWindowType type, const std::string &text, int x, int y, int color, bool blink) {
    WINDOW *targetWindow = getWindowByType(type);

    if (blink) {
        wattron(targetWindow, A_BLINK);
    }

    wattron(targetWindow, COLOR_PAIR(color));

    mvwprintw(targetWindow, y, x, text.c_str());

    if (blink) {
        wattroff(targetWindow, A_BLINK);
    }

    wattroff(targetWindow, COLOR_PAIR(color));
}
