#pragma once

#include "./Header.h"

enum GUIWindowType {
    PushBoxGameObject,
    UI,
    Solver
};

class GUIWindow {
private:
    WINDOW *gameWindow;
    WINDOW *uiWindow;
    WINDOW *solverWindow;

public:
    GUIWindow();

    ~GUIWindow();

public:
    void begin();

    void end();

private:
    WINDOW *getWindowByType(GUIWindowType type);

public:
    void draw(GUIWindowType type, const std::string &text, int x, int y);

    void draw(GUIWindowType type, const std::string &text, int x, int y, int color, bool bold, bool underline);

    void draw(GUIWindowType type, const std::string &text, int x, int y, int color, bool blink);
};