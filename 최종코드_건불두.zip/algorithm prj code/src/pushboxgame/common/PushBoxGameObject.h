#pragma once
#include "Header.h"
#include "GUIWindow.h"

class GUIWindow;
class PushBoxGameObject {
public:
  int x;
  int y;

public:
  PushBoxGameObject();
  virtual ~PushBoxGameObject();

public:
  virtual void update(int keyCode);
  virtual void draw(GUIWindow& GUIWindow);
};