#include "PushBoxGameObject.h"

PushBoxGameObject::PushBoxGameObject(): x(0), y(0) {
}

PushBoxGameObject::~PushBoxGameObject() {
}

void PushBoxGameObject::update(int keyCode) {
}

void PushBoxGameObject::draw(GUIWindow& GUIWindow) {
}