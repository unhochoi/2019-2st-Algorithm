#include "./common/Header.h"
#include "./common/PushBoxGameObject.h"

class Player: public PushBoxGameObject {
public:
  Player();
  Player(int x, int y);
  ~Player();

public:
  void update(int keyCode) override;
  void draw(GUIWindow& GUIWindow) override;
};