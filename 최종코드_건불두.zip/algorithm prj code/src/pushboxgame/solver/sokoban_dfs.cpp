#include "sokoban_dfs.h"
#include "sokoban_function.h"

/* Function executes depth first search algorithm on an inital state.
 *  Due to sokoban puzzles having infinite depth, an explored list is
 *  used to prevent infinite loops.
 * 
 * Preconditions: Takes in a State object for initial state of level
 * Postconditions: Returns a SearchStat object for search results stats
 */
SearchStat dfs(State &initial_state)
{
	std::deque<State> open;
	std::vector<State> closed;
	SearchStat report;
	report.rep_node_count = 0;
	report.fringe_node = 0;
	report.explored_count = 1;//will be replaced, just to stop cout spam
	report.node_count = 1;
	report.node.state_str = "NULL";
	State current_state;
	
	//push first state into queue
	open.push_back(initial_state);
	while (!open.empty())
	{
		//take N from OPEN
		current_state = open.front();
		open.pop_front();
		//push N onto CLOSED
		closed.push_back(current_state);
		SearchStat temp_output;
		//print out in case a long time is taken and wondering if it froze
		if ((closed.size() % 5000) == 0)
			{	
				temp_output.node.state_str = "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn";
				temp_output.node.move_list = "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn";
				return temp_output;}
			
		//if found, set report node to current node, set explored count to closed list size
		if (is_goal(current_state))
		{
			report.node = current_state;
			report.explored_count = closed.size();
			open.pop_front();
			break;
		}
		
		//generate valid states
		std::queue<State> valid_states = gen_valid_states(current_state, DFS);
		std::deque<State>::iterator it;
		std::vector<State>::iterator itr;
		std::deque<State> temp_open;
		
		//while queue is not empty of states
		while (!valid_states.empty())
		{
			bool already_seen = false;
			State temp_state = valid_states.front();
			//check if state has already been seen on open list
			for (it = open.begin(); it != open.end(); it++)
			{
				if (it->state_str == temp_state.state_str)
				{
					already_seen = true;
					break;
				}
			}
			//check if state has already been seen on closed list
			for (itr = closed.begin(); itr != closed.end(); itr++)
			{
				if (itr->state_str == temp_state.state_str)
				{
					already_seen = true;
					break;
				}
			}
			//if not duplicate, then add state to open queue
			if (!already_seen)
			{
				report.node_count++;
				//uses a temporary queue to reverse the node order
				temp_open.push_front(temp_state);
			}
			else
				report.rep_node_count++;
			valid_states.pop();
		}
		//reverses the reversed queue to keep left to right searches in the dfs
		while (!temp_open.empty())
		{
			State temp_state = temp_open.front();
			open.push_front(temp_state);
			temp_open.pop_front();
		}
	}
	report.fringe_node = open.size();
	return report;
} //SearchStat dfs(State &initial_state)

