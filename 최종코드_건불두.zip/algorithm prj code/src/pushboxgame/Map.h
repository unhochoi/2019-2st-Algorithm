#include "./common/Header.h"
#include "./common/PushBoxGameObject.h"

class Map: public PushBoxGameObject {
public:
  int width;
  int height;
  int** map;
  int** boxMap;

private:
  std::stack<Movement> pushHistorys;

public:
  int startX;
  int startY;

private:
  int offsetX;
  int offsetY;

public:
  Map(const std::string& fileName);
  Map(const Map& map);
  ~Map();

private:
  int getBlock(int x, int y);
  void setBlock(int x, int y, int block);

private:
  int getBoxBlock(int x, int y);
  void setBoxBlock(int x, int y, int block);

public:
  bool isMoveable(int x, int y);
  bool isPushable(int x, int y, Direction d);

  bool isClear();

public:
  void push(int x, int y, Direction d);
  void undo();

public:
  void draw(GUIWindow& GUIWindow) override;
};