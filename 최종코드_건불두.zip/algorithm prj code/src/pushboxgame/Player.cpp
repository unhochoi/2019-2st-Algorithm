#include "Player.h"

Player::Player() {
}

Player::Player(int x, int y) {
  this->x = x;
  this->y = y;
}

Player::~Player() {
}

void Player::update(int keyCode) {
  int dx = 0, dy = 0;
  
  Direction d = getDirectionFromKeyCode(keyCode);
  getPointFromDirection(d, dx, dy);

  x += dx;
  y += dy;
}

void Player::draw(GUIWindow& GUIWindow) {
  GUIWindow.draw(GUIWindowType::PushBoxGameObject, "&", this->x, this->y, 0, true, false);
}