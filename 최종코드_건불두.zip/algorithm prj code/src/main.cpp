#include "./pushboxgame/PushBoxGame.h"

int main(int argc, char *argv[]) {
  PushBoxGame game(argc, argv[1]);
  game.run();

  return 0;
}